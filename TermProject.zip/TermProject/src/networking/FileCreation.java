package networking;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;





public class FileCreation  {
    public static void main(String[] args) throws Exception {

        FileWriter fw = new FileWriter("SortedScore.txt");
        fw.close();



    }

}
