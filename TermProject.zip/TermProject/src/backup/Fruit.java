package backup;

import javafx.scene.image.Image;

import java.util.ArrayList;


public class Fruit {
    static ArrayList<String> fruitimg=new ArrayList<String>();
    static ArrayList<String>  power=new ArrayList<String>();

    public Fruit(ArrayList<String> fruitimg,ArrayList<String>power){
        this.fruitimg=fruitimg;
        this.power=power;

    }





}
