package backup;

import java.util.ArrayList;

public class Bomb {
    static ArrayList<String>bombs=new ArrayList<String>();

    public Bomb(ArrayList<String> bombs){
        this.bombs=bombs;
    }
}
